# يمن ستور - Yemen Store

## التشغيل محليًا
1. `npm install`
2. انسخ `.env.example` إلى `.env.local` واملأ القيم (خاصة `ADMIN_INITIAL_PASSWORD` و `SESSION_SECRET` و `FIREBASE_SERVICE_ACCOUNT_JSON`).
3. `npm run dev`

## تغييرات الأمان (مهم)
- كلمات المرور تُحفظ الآن بتشفير scrypt مع salt، ولا تُخزَّن أو تُعرض بنص صريح.
- الحسابات القديمة تُرقّى تلقائيًا عند أول تسجيل دخول ناجح.
- أُزيلت كلمة مرور المدير الثابتة من الكود. تُؤخذ من `ADMIN_INITIAL_PASSWORD`.
- السيرفر يتعامل مع `storeAccounts` و `_otps` عبر Firebase Admin، وقواعد Firestore تمنع المتصفح منها بالكامل.
- **يلزم** ضبط `FIREBASE_SERVICE_ACCOUNT_JSON` على Vercel، وإلا لن يستطيع السيرفر الوصول لهذه المجموعات.

- مسارات تغيير كلمة المرور وتحديث الملف الشخصي تتطلب الآن تسجيل دخول، ولا يستطيع المستخدم تعديل حساب غيره.
- تغيير كلمة المرور يتطلب كلمة المرور الحالية (إلا لمسؤول يعيّن كلمة لمستخدم آخر).
- حدّ للمحاولات على تسجيل الدخول والتسجيل وإرسال رموز OTP، وترويسات حماية للمتصفح.
- مسؤول Firebase يُعتمد فقط إذا كان بريده موثّقًا.

## النشر
1. ارفع المشروع إلى GitHub واربطه بـ Vercel.
2. أضف متغيرات `.env.example` في Vercel (Project Settings ← Environment Variables).
3. انشر قواعد Firestore: `firebase deploy --only firestore:rules` (أو الصق `firestore.rules` في Firebase Console).
4. بعد أول تسجيل دخول للمدير، غيّر كلمة المرور من الحساب.

## التطبيق القابل للتثبيت
- الموقع PWA: افتحه من Chrome على الجوال ← "تثبيت التطبيق" / "إضافة إلى الشاشة الرئيسية".
- لملف APK: ادخل pwabuilder.com، أدخل رابط الموقع، واختر Android. ثم ضع بصمة SHA-256 الخاصة بتوقيعك في `public/.well-known/assetlinks.json`.
