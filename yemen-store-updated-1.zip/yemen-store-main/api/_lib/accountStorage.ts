import crypto from "crypto";
import { FieldValue, type Firestore } from "firebase-admin/firestore";
import { getFirebaseAdmin } from "./firebaseAdmin.js";

export interface StoreAccount {
  uid: string;
  email: string;
  name: string;
  phone?: string;
  photoURL?: string;
  /** @deprecated plaintext passwords are no longer stored; kept only to migrate old records */
  password?: string;
  passwordHash?: string;
  role: "admin" | "store" | "user" | "delivery";
  status: "active" | "suspended";
  pointsBalance: number;
  agreedToDisclaimer: boolean;
  createdAt: string;
  lastLoginAt: string;
}

// In-memory cache for instant lookups & dev resilience
const memoryAccountsStore = new Map<string, StoreAccount>();

// Auto-seed master admin account
const MASTER_ADMIN_EMAIL = "1ismaai0lll@gmail.com";

// The initial admin password must come from the environment. If it is missing we
// generate a random one (printed once in the server log) instead of a hardcoded default.
let generatedAdminPass: string | null = null;
function getInitialAdminPassword(): string {
  const fromEnv = (process.env.ADMIN_INITIAL_PASSWORD || "").trim();
  if (fromEnv.length >= 8) return fromEnv;
  if (!generatedAdminPass) {
    generatedAdminPass = crypto.randomBytes(12).toString("base64url");
    console.warn("[SECURITY] ADMIN_INITIAL_PASSWORD not set. Temporary admin password for this run:", generatedAdminPass);
  }
  return generatedAdminPass;
}
export const MASTER_ADMIN_UID = "MQAwCYqFztd2PZbV1fRMxKRqoYX2";

export function getAccountDocId(email: string): string {
  const hash = crypto
    .createHash("sha256")
    .update(email.trim().toLowerCase())
    .digest("hex")
    .slice(0, 24);
  return `acc_${hash}`;
}

// Salted scrypt hash. Format: scrypt$<salt hex>$<hash hex>
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password.trim(), salt, 64);
  return `scrypt$${salt.toString("hex")}$${hash.toString("hex")}`;
}

function legacySha256(password: string): string {
  return crypto.createHash("sha256").update(password.trim()).digest("hex");
}

export function isLegacyHash(stored?: string): boolean {
  return !!stored && !stored.startsWith("scrypt$");
}

/** Verifies a password against a stored scrypt hash (or an old unsalted SHA-256 hash). */
export function verifyPassword(password: string, stored?: string): boolean {
  if (!stored) return false;
  try {
    if (stored.startsWith("scrypt$")) {
      const [, saltHex, hashHex] = stored.split("$");
      const expected = Buffer.from(hashHex, "hex");
      const actual = crypto.scryptSync(password.trim(), Buffer.from(saltHex, "hex"), expected.length);
      return crypto.timingSafeEqual(actual, expected);
    }
    const a = Buffer.from(legacySha256(password));
    const b = Buffer.from(stored);
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

// Ensure master admin is pre-populated
export function seedMasterAdmin(): StoreAccount {
  const existing = memoryAccountsStore.get(MASTER_ADMIN_EMAIL);
  if (existing) {
    existing.uid = MASTER_ADMIN_UID;
    existing.role = "admin";
    return existing;
  }

  const adminAccount: StoreAccount = {
    uid: MASTER_ADMIN_UID,
    email: MASTER_ADMIN_EMAIL,
    name: "Ismail Ali",
    phone: "777000000",
    passwordHash: hashPassword(getInitialAdminPassword()),
    role: "admin",
    status: "active",
    pointsBalance: 10000,
    agreedToDisclaimer: true,
    createdAt: "2026-01-01T00:00:00.000Z",
    lastLoginAt: new Date().toISOString()
  };
  memoryAccountsStore.set(MASTER_ADMIN_EMAIL, adminAccount);
  return adminAccount;
}

// Initialize seed
seedMasterAdmin();

export async function getAccountByEmail(email: string): Promise<StoreAccount | null> {
  const normalizedEmail = email.trim().toLowerCase();
  const docId = getAccountDocId(normalizedEmail);

  // 1. In-memory check
  if (memoryAccountsStore.has(normalizedEmail)) {
    const cached = memoryAccountsStore.get(normalizedEmail)!;
    if (normalizedEmail === MASTER_ADMIN_EMAIL) {
      cached.uid = MASTER_ADMIN_UID;
      cached.role = "admin";
    }
    return cached;
  }

  // 2. Direct Server Firestore check
  const db = getServerFirestore();
  if (db) {
    try {
      const snap = await db.collection("storeAccounts").doc(docId).get();
      if (snap.exists) {
        const acc = snap.data() as StoreAccount;
        if (normalizedEmail === MASTER_ADMIN_EMAIL) {
          acc.uid = MASTER_ADMIN_UID;
          acc.role = "admin";
        }
        memoryAccountsStore.set(normalizedEmail, acc);
        return acc;
      }

      // Also check users collection to preserve profile modifications
      const targetUid = normalizedEmail === MASTER_ADMIN_EMAIL ? MASTER_ADMIN_UID : `u_${docId.slice(4)}`;
      const userSnap = await db.collection("users").doc(targetUid).get();
      if (userSnap.exists) {
        const u = userSnap.data() || {};
        const acc: StoreAccount = {
          uid: targetUid,
          email: normalizedEmail,
          name: u.name || "مستخدم",
          phone: u.phone || "",
          photoURL: u.photoURL || "",
          passwordHash: hashPassword(
            normalizedEmail === MASTER_ADMIN_EMAIL ? getInitialAdminPassword() : crypto.randomBytes(24).toString("hex")
          ),
          role: normalizedEmail === MASTER_ADMIN_EMAIL ? "admin" : (u.role || "user"),
          status: "active",
          pointsBalance: u.pointsBalance || 0,
          agreedToDisclaimer: true,
          createdAt: u.createdAt || new Date().toISOString(),
          lastLoginAt: new Date().toISOString()
        };
        memoryAccountsStore.set(normalizedEmail, acc);
        return acc;
      }
    } catch (err: any) {
      console.warn("Direct firestore account get notice:", err?.message);
    }
  }

  // If master admin and not found yet in Firestore, guarantee existence
  if (normalizedEmail === MASTER_ADMIN_EMAIL) {
    return seedMasterAdmin();
  }

  return null;
}

export async function saveAccount(account: StoreAccount): Promise<boolean> {
  const normalizedEmail = account.email.trim().toLowerCase();
  const docId = getAccountDocId(normalizedEmail);

  if (normalizedEmail === MASTER_ADMIN_EMAIL) {
    account.uid = MASTER_ADMIN_UID;
    account.role = "admin";
    if (!account.name) {
      account.name = "Ismail Ali";
    }
  }

  // Never keep a plaintext password
  delete account.password;

  // Update in memory
  memoryAccountsStore.set(normalizedEmail, account);

  // 1. Direct Server Firestore Client SDK (Primary & 100% reliable)
  const db = getServerFirestore();
  if (db) {
    try {
      await db.collection("storeAccounts").doc(docId).set({ ...account, password: FieldValue.delete() }, { merge: true });
      // Sync to users collection so existing app queries keep working
      await db.collection("users").doc(account.uid).set({
        name: account.name,
        email: account.email,
        phone: account.phone || "",
        photoURL: account.photoURL || "",
        role: account.role,
        pointsBalance: account.pointsBalance || 0,
        agreedToDisclaimer: Boolean(account.agreedToDisclaimer),
        createdAt: account.createdAt,
        lastSeen: account.lastLoginAt,
        isOnline: true
      }, { merge: true });
      return true;
    } catch (err: any) {
      console.warn("Server Firestore save notice:", err?.message);
    }
  }

  return true;
}

export async function getAllAccounts(): Promise<StoreAccount[]> {
  seedMasterAdmin();
  const accountsMap = new Map<string, StoreAccount>();

  // Load from memory first
  memoryAccountsStore.forEach((acc, email) => {
    accountsMap.set(email, acc);
  });

  // Direct Server Firestore list
  const db = getServerFirestore();
  if (db) {
    try {
      const snap = await db.collection("storeAccounts").get();
      snap.forEach((d) => {
        const acc = d.data() as StoreAccount;
        if (acc?.email) {
          accountsMap.set(acc.email.toLowerCase(), acc);
          memoryAccountsStore.set(acc.email.toLowerCase(), acc);
        }
      });
    } catch (err: any) {
      console.warn("Server firestore list notice:", err?.message);
    }
  }

  return Array.from(accountsMap.values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export async function deleteAccountRecord(identifier: string): Promise<boolean> {
  const normalized = identifier.trim().toLowerCase();
  if (normalized === MASTER_ADMIN_UID) {
    return false; // Cannot delete primary master admin UID
  }

  let targetEmail = "";
  let targetUid = "";

  if (normalized.includes("@")) {
    targetEmail = normalized;
    if (targetEmail === MASTER_ADMIN_EMAIL) {
      return false; // Cannot delete master email globally
    }
    const existing = await getAccountByEmail(normalized);
    if (existing) targetUid = existing.uid;
  } else {
    targetUid = identifier.trim();
    if (targetUid === MASTER_ADMIN_UID) {
      return false;
    }
    for (const [em, acc] of memoryAccountsStore.entries()) {
      if (acc.uid === targetUid) {
        targetEmail = em;
        break;
      }
    }
  }

  const docId = targetEmail ? getAccountDocId(targetEmail) : "";
  if (targetEmail && targetEmail !== MASTER_ADMIN_EMAIL) {
    memoryAccountsStore.delete(targetEmail);
  }

  // 1. Delete from Firestore via direct Server Firestore Client SDK
  const db = getServerFirestore();
  if (db) {
    try {
      if (docId && targetEmail !== MASTER_ADMIN_EMAIL) {
        await db.collection("storeAccounts").doc(docId).delete();
      }
      if (targetUid && targetUid !== MASTER_ADMIN_UID) {
        await db.collection("users").doc(targetUid).delete();
      }
      // Also delete any matching document in users by email if not master admin
      if (targetEmail && targetEmail !== MASTER_ADMIN_EMAIL) {
        const uSnap = await db.collection("users").where("email", "==", targetEmail).get();
        for (const uDoc of uSnap.docs) {
          if (uDoc.id !== MASTER_ADMIN_UID) {
            await db.collection("users").doc(uDoc.id).delete();
          }
        }
      }
    } catch (err: any) {
      console.warn("Delete account notice:", err.message);
    }
  }

  return true;
}
