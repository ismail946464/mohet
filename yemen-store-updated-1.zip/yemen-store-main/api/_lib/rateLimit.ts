// Simple in-memory rate limiter (per server instance). Slows down password guessing and OTP abuse.
const buckets = new Map<string, { count: number; resetAt: number }>();

export function getClientIp(req: any): string {
  const fwd = req.headers?.["x-forwarded-for"];
  const first = Array.isArray(fwd) ? fwd[0] : typeof fwd === "string" ? fwd.split(",")[0] : "";
  return (first || req.socket?.remoteAddress || "unknown").trim();
}

/** Returns true when the request is allowed, false when the limit is exceeded. */
export function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) if (v.resetAt <= now) buckets.delete(k);
  }
  const b = buckets.get(key);
  if (!b || b.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  b.count += 1;
  return b.count <= max;
}

/** Sends a 429 and returns false if the caller is over the limit. */
export function enforceRateLimit(req: any, res: any, name: string, max: number, windowMs: number): boolean {
  if (checkRateLimit(`${name}:${getClientIp(req)}`, max, windowMs)) return true;
  res.status(429).json({ success: false, message: "محاولات كثيرة. يرجى الانتظار بضع دقائق ثم المحاولة مرة أخرى." });
  return false;
}
